LBK-BKNSN
Producten:
•	BKNSN_2023.shp
•	BKNSN_2023.lyrx
•	BKNSN_2023.qml (bijbehorende style-file voor QGIS (qgis.org))

De Basiskaart Natuurlijk Systeem Nederland  (BKNSN) is een afgeleid kaartproduct van de Landschappelijke bodemkartering (LBK; Van Delft & Maas, 2023). 
De Basiskaart Natuurlijk Systeem (BKNSN) is ontwikkeld om beter inzicht te krijgen in de kenmerken van het natuurlijke landschap. 
Landvormen en bodemfysische eigenschappen bepalen waar klimaatdreigingen als wateroverlast of droogte kunnen voorkomen of waar juist adaptatiekansen liggen voor de effecten van klimaatverandering. 
Met het oog op deze impacts zijn de eenheden van de landschappelijke bodemkaart opnieuw geclusterd. 
Deze van de LBK afgeleide kaart duiden we aan met de LBK-BKNSN en is onder de noemer Basiskaart natuurlijk systeem Nederland opgenomen in de Klimaateffectatlas. 
Voor deze versie van de LBK-BKNSN is gebruik gemaakt van de volgende bronbestanden:

•	Landschappelijke bodemkaart versie 2023 (https://bodemdata.nl/themakaarten)
•	Geomorfologische kaart Nederland (Versie 2022)
•	Archeologische landschappenkaart (RCE)
•	Basiskaart Natuurlijk Systeem Nederland (Versie 2021)
•	Begraven landschappenkaart (RCE/UU)

De huidige versie van de LBK-BKNSN is bekend onder Basiskaart Natuurlijk Systeem Nederland versie 2023. 
De benodigde R-files en ArcGIS models voor het genereren van de BKNSN zijn gearchiveerd bij Wageningen Environmental Research. 
Een interactieve versie van de BKNSN met de gekoppelde klimaateffecten en adaptatiekansen is te vinden op https://www.klimaateffectatlas.nl/nl/.

Bronnen

Van Delft, S. P. J. & Maas, G. J., 2023. De Landschappelijke Bodemkaart van Nederland; versie 2023 Beta. Wageningen, Wageningen Environmental Research. https://bodemdata.nl/themakaarten

https://www.cultureelerfgoed.nl/onderwerpen/bronnen-en-kaarten/overzicht/archeologische-landschappenkaart

https://www.klimaateffectatlas.nl/nl/basiskaart-natuurlijk-systeem-nederland

https://www.cultureelerfgoed.nl/onderwerpen/bronnen-en-kaarten/overzicht/begraven-landschappen.



Licentie: CC BY 4.0 (zie directory "Creative Commons License")
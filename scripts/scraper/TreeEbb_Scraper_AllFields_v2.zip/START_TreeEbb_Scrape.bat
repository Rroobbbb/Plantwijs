@echo off
setlocal
cd /d "%~dp0"

echo.
echo === TreeEbb scraper starten ===
echo.

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo Scraper draait nu... (sluit dit venster pas als hij klaar is)
echo.

python treeebb_scraper_allfields.py

echo.
echo Klaar! Druk op een toets om af te sluiten.
pause >nul

README - TreeEbb scraper (alle velden)

Wat doet dit?
- Maakt een CSV met ALLE "kenmerken/filters" per TreeEbb plant.
- Gebaseerd op het 'plant-specs' blok (zoals je HTML-fragment).
- Sluit beschrijvingtekst en foto's uit.

Starten met 1 klik
1) Installeer Python (3.10+).
2) Dubbelklik: START_TreeEbb_Scrape.bat

Output
- C:\PlantWijs\data\treeebb_planten_allfields.csv
- URL-cache: C:\PlantWijs\data\treeebb_urls.txt

Testen (optioneel)
- 50 planten: python treeebb_scraper_allfields.py --max 50
- Browser zichtbaar: python treeebb_scraper_allfields.py --no-headless
- URL's opnieuw ophalen: python treeebb_scraper_allfields.py --fresh
